"""Feed quality: Great Expectations contracts per department feed."""
import os
os.environ.setdefault("MDM_AUTH_DISABLED", "true")
os.environ["MDM_BASE"] = ""
import great_expectations as gx
import great_expectations.expectations as gxe
from fastapi.testclient import TestClient
from app import quality
from app.api import app

c = TestClient(app)


def _ctx():
    ctx = gx.get_context(mode="ephemeral")
    return ctx


def _row(rid, **k):
    base = {"source_rid": rid, "name": "Asha Rao", "gender": "F", "dob": "1990-01-02", "age": None, "birth_year": None,
            "district": "Medak", "address": "1-2 Main Rd", "ration_card": None, "as_of": "2026-06-10"}
    base.update(k)
    return base


def test_clean_feed_passes_with_no_critical_failure():
    rows = [_row(f"PN-{i:07d}", name=f"Person {i} Rao") for i in range(1, 40)]
    res = quality._run_source(_ctx(), gx, gxe, "pension_batch", rows)
    assert res and all(r["success"] for r in res if r["severity"] == "critical")
    assert quality.source_status(res) in ("PASS", "WARN")


def test_broken_feed_fails_on_key_value_and_format_problems():
    rows = [_row("PN-0000001"), _row("PN-0000001"), _row("BADKEY", name=None), _row("PN-0000003", gender="X"),
            _row("PN-0000004", dob="1850-01-01"), _row("PN-0000005", age=240), _row("PN-0000006", as_of="yesterday")]
    res = quality._run_source(_ctx(), gx, gxe, "pension_batch", rows)
    failed = {(r["expectation"], r["column_name"]) for r in res if not r["success"] and r["severity"] == "critical"}
    for want in [("expect_column_values_to_be_unique", "source_rid"), ("expect_column_values_to_match_regex", "source_rid"),
                 ("expect_column_values_to_not_be_null", "name"), ("expect_column_values_to_be_in_set", "gender"),
                 ("expect_column_values_to_be_between", "dob_year"), ("expect_column_values_to_be_between", "age"),
                 ("expect_column_values_to_match_regex", "as_of")]:
        assert want in failed, want
    assert quality.source_status(res) == "FAIL"
    bad = next(r for r in res if r["expectation"] == "expect_column_values_to_be_in_set")
    assert bad["samples"] and bad["samples"][0]["source_rid"] == "PN-0000003", "a failing result names the record that failed"


def test_missing_optional_field_is_only_a_warning():
    rows = [_row(f"PN-{i:07d}", name=f"Person {i} Rao", dob=None) for i in range(1, 30)]
    res = quality._run_source(_ctx(), gx, gxe, "pension_batch", rows)
    assert quality.source_status(res) == "WARN"


def test_run_is_kept_and_readable_through_the_api():
    r = c.post("/api/x/quality/run")
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["totals"]["feeds"] >= 1 and d["gx_version"]
    latest = c.get("/api/x/quality/latest").json()
    assert latest["run"]["id"] == d["id"] and latest["results"]
    row = latest["results"][0]
    assert row["severity"] in ("critical", "advisory") and row["description"] and row["expectation"].startswith("expect_")
    assert any(f["name"] for f in latest["summary"]["feeds"].values())
    runs = c.get("/api/x/quality/runs").json()["items"]
    assert runs and runs[0]["id"] == d["id"]
    assert c.get(f"/api/x/quality/runs/{d['id']}").status_code == 200
    assert c.get("/api/x/quality/runs/99999999").status_code == 404
