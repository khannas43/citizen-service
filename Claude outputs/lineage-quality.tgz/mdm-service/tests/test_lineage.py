"""Lineage: field, record and flow level, the sources-to-consumers overview, and the OpenLineage-shaped export."""
import os
os.environ.setdefault("MDM_AUTH_DISABLED", "true")
os.environ["MDM_BASE"] = ""
from fastapi.testclient import TestClient
from app.api import app

c = TestClient(app)


def _multi_source_person():
    r = c.get("/api/persons", params={"min_sources": 4, "limit": 5})
    assert r.status_code == 200, r.text
    return r.json()["items"][0]["id"]


def test_person_lineage_shows_each_system_its_records_and_which_value_won():
    r = c.get(f"/api/x/lineage/person/{_multi_source_person()}")
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["summary"]["systems"] >= 4 and d["summary"]["records"] >= d["summary"]["systems"]
    rec = d["sources"][0]["records"][0]
    assert rec["source_rid"] and rec["link_status"] and "loaded_at" in rec
    name = next(f for f in d["fields"] if f["attribute"] == "name")
    assert name["rule"] and name["chosen_source_name"]
    assert sum(1 for o in name["offers"] if o["chosen"]) == 1, "exactly one offer is marked as the winner"
    assert all(o["source_name"] for o in name["offers"])


def test_person_lineage_unknown_person_is_404():
    assert c.get("/api/x/lineage/person/999999999").status_code == 404


def test_event_flow_runs_from_source_to_event_and_lists_what_followed():
    ev = c.get("/api/x/events", params={"limit": 50}).json()["items"]
    pick = next((e for e in ev if e.get("delivered") or e.get("open_proposals")), ev[0])
    r = c.get(f"/api/x/lineage/event/{pick['id']}")
    assert r.status_code == 200, r.text
    d = r.json()
    kinds = {n["kind"] for n in d["nodes"]}
    assert {"source", "event"} <= kinds
    ids = {n["id"] for n in d["nodes"]}
    assert all(e["from"] in ids and e["to"] in ids for e in d["edges"]), "every edge joins two nodes that exist"
    assert any(e["from"] == "src" and e["to"] == "ev" for e in d["edges"])


def test_overview_counts_match_the_records_and_name_consumers():
    d = c.get("/api/x/lineage/overview").json()
    assert d["core"]["records"] == sum(s["records"] for s in d["sources"]) > 0
    assert all(s["name"] and "loaded_at" in s for s in d["sources"])
    assert d["core"]["persons"] > 0 and d["outputs"] and isinstance(d["consumers"], list)


def test_export_is_openlineage_shaped_with_inputs_and_outputs():
    d = c.get("/api/x/lineage/export").json()
    assert d["events"] and all(e["eventType"] == "COMPLETE" and e["job"]["name"] and "inputs" in e and "outputs" in e for e in d["events"])
    first = d["events"][0]
    assert len(first["inputs"]) >= 8 and first["outputs"][0]["name"] == "mdm.source_record"
