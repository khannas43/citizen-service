"""Feed quality API under /api/x/quality."""
from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException

from . import auth, quality
from .api import cur_dep

router = APIRouter()


@router.post("/api/x/quality/run")
def start(u=Depends(auth.can_write)):
    return quality.run(u["actor"] or "officer", "MANUAL")


@router.get("/api/x/quality/runs")
def runs(limit: int = 20, cur=Depends(cur_dep), _=Depends(auth.can_read)):
    return {"items": quality.list_runs(cur, max(1, min(limit, 100)))}


@router.get("/api/x/quality/latest")
def latest(cur=Depends(cur_dep), _=Depends(auth.can_read)):
    return quality.get_run(cur) or {"run": None, "summary": None, "results": []}


@router.get("/api/x/quality/runs/{run_id}")
def one(run_id: int, cur=Depends(cur_dep), _=Depends(auth.can_read)):
    r = quality.get_run(cur, run_id)
    if not r:
        raise HTTPException(404, "No such run")
    return r
