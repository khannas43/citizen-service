"""Feed quality with Great Expectations.

Each department feed has a small contract: which fields it is expected to carry and how fully, what its record keys look
like, and which values are valid. Great Expectations (GX Core 1.x) runs that contract against what was loaded from the
feed and the result of every expectation is kept, so it can be shown on a screen and compared from one run to the next.

This is quality at the door: it looks at each feed on its own. The Data quality tab in Master Data looks across feeds
(for example two departments holding different dates of birth for one person); the two are complementary.

Severity: critical = a record key or a value that must not be wrong (stops being trustworthy); advisory = how complete or
current a feed is (worth chasing with the department, but the data is usable).
"""
from __future__ import annotations
import json
import os
from datetime import date, datetime, timezone

from . import audit
from .db import connect
from .sources import SOURCE_INFO, SOURCE_ORDER
from .survivorship import REF_DATE

# a closed network: Great Expectations must not try to send usage statistics anywhere
os.environ.setdefault("GX_ANALYTICS_ENABLED", "false")

CRITICAL, ADVISORY = "critical", "advisory"

# the short key each feed uses for its records
RID = {
    "crs": r"^(CRS-EVT-[0-9a-f]+(-DUP)?|[A-Z0-9]+-[A-Z]+(-\d+)?-[0-9a-f]+)$", "identity_reference": r"^IDR-[0-9A-Z]{6,}$", "pension_batch": r"^PN-\d+$",
    "revenue_certificates": r"^RV-(CC|IC)-\d+$", "revenue_land": r"^RV-LR-\d+$", "pds_view": r"^PDS-\d+$", "student_portal": r"^STU-\d+$",
    "marriage_register": r"^(MR-\d+|[A-Z0-9]+-[A-Z]+-[0-9a-f]+)(:\w+)?$", "electricity": r"^ELEC-[0-9A-Za-z]+$", "housing": r"^HSG-[0-9A-Za-z]+$",
}

# fields a feed is expected to carry, and the share of records that should have each
FIELDS = {
    "crs": {"gender": 0.9, "dob": 0.9, "district": 0.99},
    "identity_reference": {"gender": 0.99, "birth_year": 0.99, "district": 0.99},
    "marriage_register": {"gender": 0.99, "dob": 0.95, "district": 0.95},
    "pds_view": {"gender": 0.99, "age": 0.99, "address": 0.99, "district": 0.99, "ration_card": 0.99},
    "pension_batch": {"dob": 0.95, "district": 0.99},
    "electricity": {"address": 0.99, "district": 0.99},
    "housing": {"district": 0.99},
    "revenue_certificates": {"dob": 0.8, "address": 0.99, "district": 0.99},
    "revenue_land": {"district": 0.99},
    "student_portal": {"dob": 0.99},
}
LABEL = {"dob": "date of birth", "birth_year": "year of birth", "ration_card": "ration card number", "district": "district", "address": "address",
         "gender": "gender", "age": "age", "name": "name", "source_rid": "record key", "as_of": "as-of date"}


def _frame(rows):
    import pandas as pd
    df = pd.DataFrame(rows)
    df["dob_year"] = pd.to_datetime(df["dob"], errors="coerce").dt.year.astype("float64")
    as_of = pd.to_datetime(df["as_of"].str[:10], errors="coerce")
    df["as_of_day"] = (as_of - pd.Timestamp("1970-01-01")).dt.days.astype("float64")
    df["dob"] = df["dob"].astype("string")
    return df


def _suite_for(source: str, gxe, n: int, has_asof: bool = True):
    """The expectations for one feed, each tagged with severity and a plain-language description."""
    ex = []

    def add(exp, severity, text):
        exp.meta = {"severity": severity, "description": text}
        ex.append(exp)

    add(gxe.ExpectTableRowCountToBeBetween(min_value=1), CRITICAL, "The feed delivered at least one record")
    add(gxe.ExpectColumnValuesToNotBeNull(column="source_rid"), CRITICAL, "Every record carries its department's own key")
    add(gxe.ExpectColumnValuesToBeUnique(column="source_rid"), CRITICAL, "No record key appears twice")
    add(gxe.ExpectColumnValuesToMatchRegex(column="source_rid", regex=RID[source]), CRITICAL, "Record keys follow the department's key format")
    add(gxe.ExpectColumnValuesToNotBeNull(column="name", mostly=0.99), CRITICAL, "Almost every record has a name")
    add(gxe.ExpectColumnValueLengthsToBeBetween(column="name", min_value=2, max_value=80, mostly=0.99), CRITICAL, "Names are between 2 and 80 characters")
    add(gxe.ExpectColumnValuesToBeInSet(column="gender", value_set=["M", "F"]), CRITICAL, "Gender, where given, is M or F")
    add(gxe.ExpectColumnValuesToBeBetween(column="dob_year", min_value=1900, max_value=REF_DATE.year, mostly=1.0), CRITICAL, "Dates of birth fall between 1900 and today")
    add(gxe.ExpectColumnValuesToBeBetween(column="age", min_value=0, max_value=120), CRITICAL, "Ages are between 0 and 120")
    add(gxe.ExpectColumnValuesToBeBetween(column="birth_year", min_value=1900, max_value=REF_DATE.year), CRITICAL, "Years of birth fall between 1900 and today")
    add(gxe.ExpectColumnValuesToMatchRegex(column="as_of", regex=r"^\d{4}-\d{2}-\d{2}"), CRITICAL, "As-of dates, where given, are written as dates")
    for col, share in FIELDS.get(source, {}).items():
        add(gxe.ExpectColumnValuesToNotBeNull(column=col, mostly=share), ADVISORY, f"At least {round(share * 100)}% of records carry {LABEL.get(col, col)}")
    hours = SOURCE_INFO.get(source, ("", "", 24))[2]
    window_days = (hours / 24) if hours else 30      # a continuous event feed: nothing older than a month at the latest
    if has_asof:
      add(gxe.ExpectColumnMaxToBeBetween(column="as_of_day", min_value=(REF_DATE - date(1970, 1, 1)).days - window_days, max_value=(REF_DATE - date(1970, 1, 1)).days + 1),
          ADVISORY, f"The latest record is no older than the feed's refresh window ({round(window_days)} day{'s' if round(window_days) != 1 else ''})")
    if source not in ("student_portal", "housing", "revenue_land", "electricity", "revenue_certificates"):
        dup = gxe.ExpectCompoundColumnsToBeUnique(column_list=["name", "dob", "district"], mostly=0.99, row_condition="dob.notnull() and district.notnull()", condition_parser="pandas")
        add(dup, ADVISORY, "The same name, birth date and district is not repeated within the feed")
    return ex


def _clean(x):
    """Plain JSON: pandas gives NaN / numpy numbers, which Postgres JSON does not accept."""
    if isinstance(x, dict):
        return {str(k): _clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_clean(v) for v in x]
    if x is None or isinstance(x, (bool, str)):
        return x
    try:
        import math
        f = float(x)
        if math.isnan(f) or math.isinf(f):
            return None
        return int(f) if f == int(f) and not isinstance(x, float) else f
    except (TypeError, ValueError):
        return str(x)


def _json(x):
    return _clean(x)


def _run_source(context, gx, gxe, source: str, rows: list[dict]) -> list[dict]:
    import great_expectations as _gx
    df = _frame(rows)
    ds = context.data_sources.add_or_update_pandas(name="department_feeds")
    try:
        asset = ds.get_asset(source)
    except Exception:
        asset = ds.add_dataframe_asset(name=source)
    bd = asset.add_batch_definition_whole_dataframe(f"{source}_load") if not asset.batch_definitions else asset.batch_definitions[0]
    suite = _gx.ExpectationSuite(name=f"{source}_feed_contract")
    for e in _suite_for(source, gxe, len(df), bool(df['as_of_day'].notna().any())):
        suite.add_expectation(e)
    suite = context.suites.add_or_update(suite)
    vd = context.validation_definitions.add_or_update(_gx.ValidationDefinition(name=f"{source}_validation", data=bd, suite=suite))
    res = vd.run(batch_parameters={"dataframe": df},
                 result_format={"result_format": "SUMMARY", "partial_unexpected_count": 5, "unexpected_index_column_names": ["source_rid"]})
    out = []
    for r in res.results:
        cfg = r.expectation_config
        meta = cfg.meta or {}
        rr = r.result or {}
        samples = []
        for u in (rr.get("partial_unexpected_index_list") or [])[:5]:
            samples.append(_json(u))
        if not samples:
            samples = [{"value": _json(v)} for v in (rr.get("partial_unexpected_list") or [])[:5]]
        out.append({"source": source, "expectation": cfg.type, "column_name": cfg.kwargs.get("column") or ", ".join(cfg.kwargs.get("column_list", []) or []) or None,
                    "severity": meta.get("severity", ADVISORY), "description": meta.get("description"), "success": bool(r.success),
                    "element_count": rr.get("element_count"), "unexpected_count": rr.get("unexpected_count"), "unexpected_percent": rr.get("unexpected_percent"),
                    "observed": _json({"observed_value": rr.get("observed_value")}) if rr.get("observed_value") is not None else None, "samples": samples})
    return out


def source_status(results: list[dict]) -> str:
    if any(not r["success"] and r["severity"] == CRITICAL for r in results):
        return "FAIL"
    if any(not r["success"] for r in results):
        return "WARN"
    return "PASS"


def run(actor: str = "quality-job", trigger: str = "MANUAL") -> dict:
    """Run every feed's contract once and keep the results."""
    import great_expectations as gx
    import great_expectations.expectations as gxe
    context = gx.get_context(mode="ephemeral")
    try:
        gx.set_context  # noqa: B018
        context.variables.progress_bars = {"globals": False, "metric_calculations": False, "profilers": False}
    except Exception:
        pass
    with connect() as conn:
        cur = conn.cursor()
        cur.execute("INSERT INTO mdm.quality_run (actor, gx_version, trigger) VALUES (%s,%s,%s) RETURNING id, started_at", (actor, gx.__version__, trigger))
        head = cur.fetchone()
        cur.execute("SELECT DISTINCT source FROM mdm.source_record")
        present = {r["source"] for r in cur.fetchall()}
        summary = {}
        total_fail = total_warn = 0
        for s in [x for x in SOURCE_ORDER if x in present]:
            cur.execute("SELECT source_rid, name, gender, dob::text AS dob, age, birth_year, district, address, ration_card, as_of FROM mdm.source_record WHERE source=%s", (s,))
            rows = cur.fetchall()
            results = _run_source(context, gx, gxe, s, rows)
            for r in results:
                cur.execute("""INSERT INTO mdm.quality_result (run_id, source, expectation, column_name, severity, description, success, element_count,
                               unexpected_count, unexpected_percent, observed, samples) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s::jsonb)""",
                            (head["id"], s, r["expectation"], r["column_name"], r["severity"], r["description"], r["success"], r["element_count"],
                             r["unexpected_count"], r["unexpected_percent"], json.dumps(r["observed"]) if r["observed"] else None, json.dumps(r["samples"])))
            st = source_status(results)
            summary[s] = {"status": st, "records": len(rows), "expectations": len(results), "passed": sum(1 for r in results if r["success"]),
                          "critical_failed": sum(1 for r in results if not r["success"] and r["severity"] == CRITICAL),
                          "advisory_failed": sum(1 for r in results if not r["success"] and r["severity"] == ADVISORY)}
            total_fail += st == "FAIL"
            total_warn += st == "WARN"
        totals = {"feeds": len(summary), "pass": sum(1 for v in summary.values() if v["status"] == "PASS"), "warn": total_warn, "fail": total_fail}
        cur.execute("UPDATE mdm.quality_run SET finished_at=now(), summary=%s::jsonb WHERE id=%s", (json.dumps({"feeds": summary, "totals": totals}), head["id"]))
        audit.write(cur, actor, "QUALITY_RUN", f"quality:{head['id']}", {"gx": gx.__version__, **totals})
        conn.commit()
    return {"id": head["id"], "gx_version": gx.__version__, "totals": totals, "feeds": summary}


# ---------------------------------------------------------------------------------------------------- reading
def list_runs(cur, limit: int = 20) -> list[dict]:
    cur.execute("SELECT id, actor, started_at, finished_at, gx_version, trigger, summary FROM mdm.quality_run ORDER BY id DESC LIMIT %s", (limit,))
    return cur.fetchall()


def get_run(cur, run_id: int | None = None) -> dict | None:
    if run_id is None:
        cur.execute("SELECT * FROM mdm.quality_run WHERE finished_at IS NOT NULL ORDER BY id DESC LIMIT 1")
    else:
        cur.execute("SELECT * FROM mdm.quality_run WHERE id=%s", (run_id,))
    r = cur.fetchone()
    if not r:
        return None
    cur.execute("SELECT * FROM mdm.quality_result WHERE run_id=%s ORDER BY source, (CASE severity WHEN 'critical' THEN 0 ELSE 1 END), id", (r["id"],))
    res = cur.fetchall()
    for x in res:
        x["unexpected_percent"] = float(x["unexpected_percent"]) if x["unexpected_percent"] is not None else None
    cur.execute("SELECT summary FROM mdm.quality_run WHERE id < %s AND finished_at IS NOT NULL ORDER BY id DESC LIMIT 1", (r["id"],))
    prev = cur.fetchone()
    feeds = (r["summary"] or {}).get("feeds", {})
    for s, v in feeds.items():
        v["name"] = SOURCE_INFO.get(s, (s,))[0]
        v["previous_status"] = ((prev or {}).get("summary") or {}).get("feeds", {}).get(s, {}).get("status")
    return {"run": {k: r[k] for k in ("id", "actor", "started_at", "finished_at", "gx_version", "trigger")}, "summary": r["summary"], "results": res}


if __name__ == "__main__":      # python -m app.quality   (run as a scheduled job)
    print(json.dumps(run("quality-job", "JOB"), indent=2, default=str))
