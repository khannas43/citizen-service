#!/bin/bash
# Run from the Citizen-Services folder:  bash INSTALL.sh <folder-with-this-package>
set -e
SRC="${1:-.}"
cd "$(dirname "$0")" 2>/dev/null || true
for f in $(cd "$SRC" && find mdm-service db scripts officer-portal -type f); do
  mkdir -p "$(dirname "$f")"
  if [ -f "$f" ]; then cat "$SRC/$f" > "$f"; else cp "$SRC/$f" "$f"; fi
  echo "  $f"
done
