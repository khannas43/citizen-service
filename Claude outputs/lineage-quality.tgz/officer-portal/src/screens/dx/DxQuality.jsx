import { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { mdm } from '../../mdmApi'
import { useMdm, Status, Badge } from '../mdm/shared'
import { PageHeader, Card, Stats, DataTable, FilterSelect, Segmented, Drawer, Facts, Banner } from './dxKit'
import { fmtTime } from './dxShared'
import './dxLineage.css'

const STATUS = { PASS: ['Passed', 'ok'], WARN: ['Passed with warnings', 'warn'], FAIL: ['Failed', 'bad'] }
const CLS = { PASS: '', WARN: 'warn', FAIL: 'bad' }
const SEV = { critical: ['Must hold', 'bad'], advisory: ['Worth chasing', 'warn'] }
const pct = (v) => (v === null || v === undefined ? '—' : `${Number(v).toFixed(v >= 10 || v === 0 ? 0 : 1)}%`)
const expName = (e) => (e || '').replace(/^expect_/, '').replace(/_/g, ' ')

export default function DxQuality() {
  const [params, setParams] = useSearchParams()
  const feed = params.get('feed') || ''
  const [result, setResult] = useState('')
  const [sev, setSev] = useState('')
  const [tick, setTick] = useState(0)
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState(null)
  const [sel, setSel] = useState(null)
  const { data, error, loading } = useMdm('/x/quality/latest', {}, [tick])
  const hist = useMdm('/x/quality/runs', { limit: 8 }, [tick])
  const setFeed = (v) => setParams(v ? { feed: v } : {})

  const run = async () => {
    setBusy(true); setMsg(null)
    try { const r = await mdm('/x/quality/run', { method: 'POST' }); setMsg({ tone: 'ok', text: `Checked ${r.totals.feeds} feeds: ${r.totals.pass} passed, ${r.totals.warn} with warnings, ${r.totals.fail} failed.` }); setTick((x) => x + 1) } catch (e) { setMsg({ tone: 'bad', text: e.message }) }
    setBusy(false)
  }

  const order = { FAIL: 0, WARN: 1, PASS: 2 }
  const feeds = Object.entries(data?.summary?.feeds || {}).sort((a, b) => order[a[1].status] - order[b[1].status])
  const t = data?.summary?.totals
  const all = data?.results || []
  const rows = all.filter((r) => (!feed || r.source === feed) && (!result || (result === 'failed' ? !r.success : r.success)) && (!sev || r.severity === sev))
  const failedAll = all.filter((r) => !r.success)

  return (
    <div className="mdm-hub">
      <PageHeader icon="✅" title="Feed quality"
        subtitle="Each department feed is checked against its own contract with Great Expectations: are the record keys present and well formed, are the values possible, and are the expected fields filled in and current. This looks at a feed on its own, before records are compared across departments."
        actions={<button type="button" className="btn-primary" onClick={run} disabled={busy}>{busy ? 'Checking…' : 'Run checks now'}</button>} />
      {msg && <Banner tone={msg.tone === 'bad' ? 'warn' : 'info'}>{msg.text}</Banner>}
      <Status loading={loading && !data} error={error} />
      {data && !data.run && <Banner tone="info">No check has been run yet. Select “Run checks now”. The same checks run on a schedule in production.</Banner>}
      {data?.run && (
        <>
          <Stats items={[
            { label: 'Feeds checked', value: t.feeds, hint: `Run ${data.run.id} · ${fmtTime(data.run.finished_at)}` },
            { label: 'Passed', value: t.pass, tone: 'ok' }, { label: 'Passed with warnings', value: t.warn, tone: t.warn ? 'warn' : 'ok' },
            { label: 'Failed', value: t.fail, tone: t.fail ? 'bad' : 'ok' },
            { label: 'Checks passed', value: `${all.filter((r) => r.success).length} of ${all.length}`, hint: `Great Expectations ${data.run.gx_version} · started by ${data.run.trigger === 'JOB' ? 'the scheduled job' : data.run.actor}` },
          ]} />

          <div className="fq-feeds" role="list">
            {feeds.map(([k, f]) => {
              const share = f.expectations ? (f.passed / f.expectations) * 100 : 0
              const moved = f.previous_status && f.previous_status !== f.status
              return (
                <button key={k} role="listitem" type="button" className={`fq-feed ${CLS[f.status]}${feed === k ? ' active' : ''}`} aria-pressed={feed === k} onClick={() => setFeed(feed === k ? '' : k)}>
                  <strong>{f.name}</strong>
                  <Badge tone={STATUS[f.status][1]}>{STATUS[f.status][0]}</Badge>
                  <div className="fq-bar"><i style={{ width: `${share}%` }} /></div>
                  <span className="lin-meta">{f.passed} of {f.expectations} checks · {f.records.toLocaleString('en-IN')} records</span>
                  {moved && <div className="fq-delta">Was: {STATUS[f.previous_status]?.[0].toLowerCase()}</div>}
                </button>
              )
            })}
          </div>

          <DataTable rows={rows} rowKey="id" pageSize={15} onRowClick={setSel} initialSort={{ key: "success", dir: "asc" }} csv={{ name: "feed-quality" }}
            search={{ placeholder: 'Search a check, field or feed', text: (r) => `${r.source} ${r.description} ${r.column_name} ${r.expectation}` }}
            canClear={!!(feed || result || sev)} onClear={() => { setFeed(''); setResult(''); setSev('') }}
            filters={<>
              <FilterSelect label="Feed" value={feed} onChange={setFeed} options={feeds.map(([k, f]) => [k, f.name])} />
              <Segmented label="Result" value={result} onChange={setResult} options={[{ value: '', label: 'All', count: all.length }, { value: 'failed', label: 'Failed', count: failedAll.length }, { value: 'passed', label: 'Passed' }]} />
              <FilterSelect label="Importance" value={sev} onChange={setSev} options={Object.entries(SEV).map(([k, v]) => [k, v[0]])} />
            </>}
            empty="No checks match" emptyHint="Clear a filter to see more."
            columns={[
              { key: 'source', label: 'Feed', render: (r) => data.summary.feeds[r.source]?.name || r.source, sort: (r) => r.source },
              { key: 'description', label: 'Check', render: (r) => <>{r.description}<div className="lin-meta">{expName(r.expectation)}{r.column_name ? ` · ${r.column_name}` : ''}</div></> },
              { key: 'severity', label: 'Importance', render: (r) => <Badge tone={SEV[r.severity]?.[1]}>{SEV[r.severity]?.[0] || r.severity}</Badge> },
              { key: 'success', label: 'Result', render: (r) => <Badge tone={r.success ? 'ok' : SEV[r.severity]?.[1] || 'warn'}>{r.success ? 'Passed' : 'Failed'}</Badge>, sort: (r) => (r.success ? 1 : 0) },
              { key: 'unexpected_count', label: 'Records affected', align: 'num', render: (r) => (r.unexpected_count != null ? `${r.unexpected_count.toLocaleString('en-IN')} (${pct(r.unexpected_percent)})` : '—'), sort: (r) => r.unexpected_count },
            ]} />

          <Card title="Earlier runs" hint="Each run is kept, so a feed that gets worse is visible." flush>
            {hist.data?.items && (
              <table className="mdm-table">
                <thead><tr><th>Run</th><th>When</th><th>Started by</th><th>Passed</th><th>Warnings</th><th>Failed</th></tr></thead>
                <tbody>
                  {hist.data.items.map((h) => (
                    <tr key={h.id}><td>{h.id}</td><td>{fmtTime(h.finished_at || h.started_at)}</td><td>{h.trigger === 'JOB' ? 'Scheduled job' : h.actor}</td>
                      <td>{h.summary?.totals?.pass ?? '—'}</td><td>{h.summary?.totals?.warn ?? '—'}</td><td>{h.summary?.totals?.fail ?? '—'}</td></tr>
                  ))}
                </tbody>
              </table>
            )}
          </Card>
        </>
      )}

      <Drawer open={!!sel} onClose={() => setSel(null)} title="Check details" subtitle={sel ? `${data.summary.feeds[sel.source]?.name || sel.source} · ${sel.success ? 'passed' : 'failed'}` : ''}>
        {sel && (
          <>
            <Facts items={[['Check', sel.description], ['Field', sel.column_name || 'whole feed'], ['Great Expectations rule', sel.expectation],
              ['Importance', SEV[sel.severity]?.[0]], ['Records looked at', sel.element_count?.toLocaleString('en-IN')], ['Records affected', sel.unexpected_count != null ? `${sel.unexpected_count.toLocaleString('en-IN')} (${pct(sel.unexpected_percent)})` : undefined],
              ['Observed', sel.observed?.observed_value !== undefined ? String(sel.observed.observed_value) : undefined]]} />
            {sel.samples?.length > 0 && (
              <>
                <h3 className="dxk-h3">Examples of records that did not pass</h3>
                <pre className="dxk-pre">{JSON.stringify(sel.samples, null, 2)}</pre>
              </>
            )}
            <p className="mdm-note">{sel.severity === 'critical' ? 'A failure here means the feed should not be trusted until the department corrects it.' : 'The data is still usable. Raise it with the department so the gap closes.'}</p>
          </>
        )}
      </Drawer>
    </div>
  )
}
