import { useMemo, useState } from 'react'
import { useMdm, Status, Badge } from '../mdm/shared'
import { fmtDate, linkLabel } from '../mdm/labels'
import { Card, Stats, DataTable, FilterSelect, Segmented } from './dxKit'
import { fmtTime } from './dxShared'
import './dxLineage.css'

const ATTR = { name: 'Name', dob: 'Date of birth', birth_year: 'Year of birth', gender: 'Gender', address: 'Address', date_of_death: 'Date of death', district: 'District' }
const show = (v) => (v === null || v === undefined || v === '' ? '—' : String(v))

/** Where one person's master record came from: which system offered which value, which won and by which rule (field level),
 *  and every department record behind it with the load that brought it in (record level). */
export default function PersonLineage({ personId, compact }) {
  const { data, error, loading } = useMdm(`/x/lineage/person/${personId}`, {}, [personId])
  const [view, setView] = useState('fields')
  const [sys, setSys] = useState('')
  const [onlyConflicts, setOnlyConflicts] = useState(false)
  const records = useMemo(() => (data ? data.sources.flatMap((s) => s.records.map((r) => ({ ...r, system: s.name, freshness_hours: s.freshness_hours }))) : []), [data])
  if (loading || error) return <Status loading={loading && !data} error={error} />
  if (!data) return null
  const s = data.summary
  const fields = data.fields.filter((f) => !onlyConflicts || f.conflict || f.distinct_values > 1)
  return (
    <div>
      {!compact && <h2 className="dxk-h3" style={{ margin: '0.25rem 0 0.6rem' }}>{data.person.name} <span className="mdm-sub">{data.person.mdm_id}</span></h2>}
      <Stats items={[
        { label: 'Systems holding this person', value: s.systems }, { label: 'Department records', value: s.records },
        { label: 'Spellings of the name', value: s.spellings, tone: s.spellings > 1 ? 'warn' : 'ok' },
        { label: 'Fields where systems disagree', value: s.conflicts, tone: s.conflicts ? 'warn' : 'ok' },
      ]} />
      <div style={{ margin: '0.25rem 0 0.75rem' }}>
        <Segmented label="Level of detail" value={view} onChange={setView}
          options={[{ value: 'fields', label: 'Field by field', count: data.fields.length }, { value: 'records', label: 'Record by record', count: records.length }]} />
      </div>

      {view === 'fields' && (
        <Card title="Which system supplied each value" hint="Every system that holds the field is shown with the value it offered. The green one was chosen for the master record, by the rule named beside it."
          actions={<label className="dxk-check"><input type="checkbox" checked={onlyConflicts} onChange={(e) => setOnlyConflicts(e.target.checked)} /> Only where systems differ</label>} flush>
          <table className="mdm-table">
            <thead><tr><th>Field</th><th>Master record shows</th><th>Offered by</th>{!compact && <th>Why this one</th>}</tr></thead>
            <tbody>
              {fields.map((f) => (
                <tr key={f.attribute}>
                  <td><strong>{ATTR[f.attribute] || f.attribute}</strong>{f.conflict && <div><Badge tone="warn">Systems disagree</Badge></div>}</td>
                  <td>{show(f.value)}<div className="lin-meta">{f.chosen_source_name}</div></td>
                  <td>
                    <div className="lin-chips">
                      {f.offers.map((o) => (
                        <span key={o.source} className={`lin-chip ${o.chosen ? 'win' : o.agrees ? 'same' : 'diff'}`} title={o.chosen ? 'Chosen' : o.agrees ? 'Agrees with the chosen value' : 'Differs from the chosen value'}>
                          {o.source_name}: {show(o.value)}{o.chosen && <small>chosen</small>}
                        </span>
                      ))}
                    </div>
                  </td>
                  {!compact && <td className="lin-meta">{f.rule}</td>}
                </tr>
              ))}
              {!fields.length && <tr><td colSpan={4} className="mdm-note">No field has disagreeing values.</td></tr>}
            </tbody>
          </table>
        </Card>
      )}

      {view === 'records' && (
        <DataTable rows={records} rowKey="id" pageSize={10} csv={{ name: `lineage-person-${data.person.id}` }}
          search={{ placeholder: 'Search system, key or name', text: (r) => `${r.system} ${r.source_rid} ${r.name}` }}
          canClear={!!sys} onClear={() => setSys('')}
          filters={<FilterSelect label="System" value={sys} onChange={setSys} options={data.sources.map((x) => [x.name, x.name])} />}
          empty="No department records"
          columns={[
            { key: 'system', label: 'System', render: (r) => <><strong>{r.system}</strong><div className="lin-meta">{r.source_rid}</div></>, sort: (r) => r.system },
            { key: 'name', label: 'Name as held', render: (r) => show(r.name) },
            { key: 'dob', label: 'Born', render: (r) => (r.dob ? fmtDate(r.dob) : r.birth_year || '—'), sort: (r) => r.dob || r.birth_year },
            { key: 'link_status', label: 'How it was linked', render: (r) => <>{linkLabel(r.link_status)}{r.score != null && <div className="lin-meta">match {Math.round(r.score * 100)}%{r.reason ? ` · ${r.reason}` : ''}</div>}</> },
            { key: 'load_id', label: 'Loaded in', render: (r) => <>Run {r.load_id}<div className="lin-meta">{fmtTime(r.loaded_at)} · rules v{r.rule_version}</div></>, sort: (r) => r.load_id },
          ]} />
      )}
    </div>
  )
}
