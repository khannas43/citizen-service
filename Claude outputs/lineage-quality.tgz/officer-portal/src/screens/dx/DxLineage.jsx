import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { mdm } from '../../mdmApi'
import { useMdm, Status, Badge } from '../mdm/shared'
import { PageHeader, Card, Tabs, DataTable, Banner, Stats } from './dxKit'
import { PersonPicker, fmtTime } from './dxShared'
import PersonLineage from './PersonLineage'
import FlowGraph from './FlowGraph'
import './dxLineage.css'

const n = (v) => (v ?? 0).toLocaleString('en-IN')
const CONNECTOR = { ACTIVE: 'live', TESTING: 'tested, not live', DRAFT: 'draft', SUSPENDED: 'suspended' }

function Overview() {
  const nav = useNavigate()
  const { data, error, loading } = useMdm('/x/lineage/overview', {}, [])
  if (loading || error) return <Status loading={loading && !data} error={error} />
  if (!data) return null
  const c = data.core
  return (
    <>
      <Banner tone="info">Read left to right. Departments hand their records in; master data links and merges them; the exchange publishes events and answers questions from the result; the departments and services on the right consume it. Select any box to see the detail behind it.</Banner>
      <div className="lin-pipe">
        <div className="lin-col">
          <h3 className="lin-col-h">1 · Source systems</h3>
          {data.sources.map((s) => (
            <button key={s.source} type="button" className={`lin-box${s.open_issues ? ' warn' : ''}`} onClick={() => nav(`/dx/quality?feed=${s.source}`)} aria-label={`${s.name}: open feed quality`}>
              <strong>{s.name}</strong>
              <span className="lin-meta">{s.interface}{s.connector ? ` · ${CONNECTOR[s.connector] || s.connector}` : ''}</span>
              <div className="lin-chips">
                <span className="lin-chip">{n(s.records)} records</span>
                <span className="lin-chip">{n(s.linked)} linked</span>
                {s.in_review > 0 && <span className="lin-chip diff">{n(s.in_review)} in review</span>}
                {s.open_issues > 0 && <span className="lin-chip diff">{n(s.open_issues)} open issues</span>}
              </div>
              <span className="lin-meta">Last loaded {fmtTime(s.loaded_at)}{s.latest ? ` · newest record ${s.latest}` : ''}</span>
            </button>
          ))}
        </div>
        <div className="lin-arrow" aria-hidden="true">➜</div>
        <div className="lin-col">
          <h3 className="lin-col-h">2 · Master data</h3>
          <button type="button" className="lin-box core" onClick={() => nav('/mdm?tab=people')}><strong>People</strong><span className="lin-n">{n(c.persons)}</span><span className="lin-meta">from {n(c.records)} department records</span></button>
          <div className="lin-box core"><strong>Chosen values</strong><span className="lin-n">{n(c.golden_attributes)}</span><span className="lin-meta">each with its source and rule</span></div>
          <button type="button" className="lin-box core" onClick={() => nav('/mdm?tab=people')}><strong>Family links</strong><span className="lin-n">{n(c.relationships)}</span><span className="lin-meta">parent, spouse, household</span></button>
          <button type="button" className={`lin-box ${c.review_open ? 'warn' : 'core'}`} onClick={() => nav('/mdm?tab=review')}><strong>Waiting for a steward</strong><span className="lin-n">{n(c.review_open)}</span><span className="lin-meta">possible matches needing a human</span></button>
          {c.last_load && <span className="lin-meta">Latest load: run {c.last_load.id}, {fmtTime(c.last_load.finished_at)}, rules v{c.last_load.rule_version}</span>}
        </div>
        <div className="lin-arrow" aria-hidden="true">➜</div>
        <div className="lin-col">
          <h3 className="lin-col-h">3 · What the exchange produces</h3>
          {data.outputs.map((o) => (
            <div key={o.kind} className="lin-box out"><strong>{o.label}</strong><span className="lin-n">{n(o.count)}</span></div>
          ))}
        </div>
        <div className="lin-arrow" aria-hidden="true">➜</div>
        <div className="lin-col">
          <h3 className="lin-col-h">4 · Who uses it</h3>
          {data.consumers.map((x) => (
            <div key={x.system} className="lin-box con"><strong>{x.name}</strong>
              <span className="lin-meta">{x.events_total ? `${n(x.events_delivered)} of ${n(x.events_total)} notices delivered` : 'asks questions'}{x.answers ? ` · ${n(x.answers)} answers` : ''}</span></div>
          ))}
        </div>
      </div>
    </>
  )
}

function PersonTab({ params, setParams }) {
  const id = params.get('person')
  return (
    <>
      <Card title="Choose a person" hint="Search by name, ration card or master data id.">
        <PersonPicker onPick={(p) => setParams({ tab: 'person', person: String(p.id) })} />
      </Card>
      {id ? <PersonLineage personId={id} /> : <p className="mdm-note">Pick a person to see which systems their record came from.</p>}
    </>
  )
}

function EventTab({ params, setParams }) {
  const nav = useNavigate()
  const id = params.get('event')
  const [q, setQ] = useState('')
  const [offset, setOffset] = useState(0)
  const limit = 8
  const list = useMdm('/x/events', { q: q.trim(), limit, offset }, [q, offset])
  const flow = useMdm(id ? `/x/lineage/event/${id}` : '/x/lineage/overview', {}, [id])
  return (
    <>
      <Card title="Choose an event" hint="Follow one life event through proposals, consent, deliveries, the clearing house and the audit log." flush>
        {list.data && (
          <DataTable rows={list.data.items} server={{ total: list.data.total, limit, offset, onPage: setOffset }} searchValue={q} onSearch={(v) => { setQ(v); setOffset(0) }} searchDelay={300}
            search={{ placeholder: 'Search by event key, type or person' }} onRowClick={(e) => setParams({ tab: 'event', event: String(e.id) })} empty="No events yet"
            columns={[
              { key: 'event_type', label: 'Event', render: (e) => (e.event_type || '').replace(/_/g, ' ').toLowerCase() },
              { key: 'uc', label: 'Use case' }, { key: 'event_key', label: 'Key', render: (e) => <span className="dx-mono">{e.event_key}</span> },
              { key: 'status', label: 'Status', render: (e) => <Badge>{(e.status || '').replace(/_/g, ' ').toLowerCase()}</Badge> },
            ]} />
        )}
      </Card>
      {id && flow.data?.nodes && (
        <Card title={`Journey of ${flow.data.event?.label || `event ${id}`}`} hint="Select a box to open the screen where it is handled.">
          <FlowGraph nodes={flow.data.nodes} edges={flow.data.edges} onOpen={(node) => node.link && nav(node.link)} />
        </Card>
      )}
      {id && <Status loading={flow.loading && !flow.data} error={flow.error} />}
      {!id && <p className="mdm-note">Pick an event to draw its journey.</p>}
    </>
  )
}

function ExportTab() {
  const { data, error, loading } = useMdm('/x/lineage/export', {}, [])
  const [busy, setBusy] = useState(false)
  const download = async () => {
    setBusy(true)
    try {
      const body = data || (await mdm('/x/lineage/export'))
      const url = URL.createObjectURL(new Blob([JSON.stringify(body, null, 2)], { type: 'application/json' }))
      const a = document.createElement('a')
      a.href = url; a.download = `citizen-lineage-openlineage-${new Date().toISOString().slice(0, 10)}.json`
      document.body.appendChild(a); a.click(); a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 1000)
    } finally { setBusy(false) }
  }
  return (
    <>
      <Banner tone="info">This is the same lineage in the OpenLineage run-event format that data catalogues ingest. OpenMetadata, which we propose for production, reads this format, so the lineage can move into the catalogue without being rebuilt. No catalogue is installed in this demonstration.</Banner>
      <Status loading={loading && !data} error={error} />
      {data && (
        <>
          <Stats items={[{ label: 'Jobs described', value: new Set(data.events.map((e) => e.job.name)).size }, { label: 'Run events', value: data.events.length },
            { label: 'Input datasets', value: new Set(data.events.flatMap((e) => e.inputs.map((i) => i.name))).size }, { label: 'Output datasets', value: new Set(data.events.flatMap((e) => e.outputs.map((i) => i.name))).size }]} />
          <Card title="Export" actions={<button type="button" className="btn-primary" onClick={download} disabled={busy}>{busy ? 'Preparing…' : 'Download JSON'}</button>} flush>
            <DataTable rows={data.events.map((e, i) => ({ ...e, id: i }))} pageSize={10} search={{ placeholder: 'Search job or dataset', text: (e) => `${e.job.name} ${e.inputs.map((i) => i.name).join(' ')} ${e.outputs.map((i) => i.name).join(' ')}` }}
              columns={[
                { key: 'job', label: 'Job', render: (e) => <strong>{e.job.name}</strong>, sort: (e) => e.job.name },
                { key: 'in', label: 'Reads', render: (e) => e.inputs.map((i) => i.name).join(', ') || '—' },
                { key: 'out', label: 'Writes', render: (e) => e.outputs.map((i) => i.name).join(', ') || '—' },
                { key: 'when', label: 'Generated', render: (e) => fmtTime(e.eventTime) },
              ]} />
          </Card>
        </>
      )}
    </>
  )
}

export default function DxLineage() {
  const [params, setParams] = useSearchParams()
  const tab = params.get('tab') || (params.get('person') ? 'person' : params.get('event') ? 'event' : 'overview')
  return (
    <div className="mdm-hub">
      <PageHeader icon="🧬" title="Data lineage"
        subtitle="Where every value in the master record came from: which department supplied it, which load brought it in, which rule chose it, and where it went next." />
      <Tabs value={tab} onChange={(t) => setParams({ tab: t })} label="Lineage views"
        tabs={[{ id: 'overview', label: 'Sources to consumers' }, { id: 'person', label: 'One person' }, { id: 'event', label: 'One event' }, { id: 'export', label: 'Catalogue export' }]} />
      {tab === 'overview' && <Overview />}
      {tab === 'person' && <PersonTab params={params} setParams={setParams} />}
      {tab === 'event' && <EventTab params={params} setParams={setParams} />}
      {tab === 'export' && <ExportTab />}
    </div>
  )
}
